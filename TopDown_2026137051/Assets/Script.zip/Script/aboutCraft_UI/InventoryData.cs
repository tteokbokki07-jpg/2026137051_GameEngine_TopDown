using System.Collections.Generic;
using System.IO;
using UnityEngine;

[System.Serializable]
public class InventoryData
{
    public int itemID;
    public int count;
}

[System.Serializable]
public class InventoryDataList
{
    public List<InventoryData> inventorySlots = new();
}

public static class InventorySaver
{
    private const string FILE = "Player_Inventory.json";

    private static string FilePath =>
        Path.Combine(Application.persistentDataPath, FILE);

    // ������ ����
    public static void SaveItem(int itemID, int count)
    {
        InventoryDataList list = LoadInternal();

        // �̹� �����ϴ� ���������� Ȯ��
        InventoryData existingItem =
            list.inventorySlots.Find(x => x.itemID == itemID);

        if (existingItem != null)
        {
            // ���� ����
            existingItem.count = count;
        }
        else
        {
            // �� ������ �߰�
            list.inventorySlots.Add(new InventoryData
            {
                itemID = itemID,
                count = count
            });
        }

        string json = JsonUtility.ToJson(list, true);
        File.WriteAllText(FilePath, json);
    }

    // ��ü ������ �ҷ�����
    public static InventoryDataList LoadInventory()
    {
        return LoadInternal();
    }

    // �������� ����
    public static void DeleteSave()
    {
        if (File.Exists(FilePath))
        {
            File.Delete(FilePath);
        }
    }

    private static InventoryDataList LoadInternal()
    {
        if (!File.Exists(FilePath))
        {
            return new InventoryDataList();
        }

        string json = File.ReadAllText(FilePath);

        InventoryDataList list =
            JsonUtility.FromJson<InventoryDataList>(json);

        return list ?? new InventoryDataList();
    }
}