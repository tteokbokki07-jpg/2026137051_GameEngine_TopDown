using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TestInventory : MonoBehaviour
{
    public static TestInventory Instance;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    [System.Serializable]
    public class ItemData
    {
        public float itemID;
        public float itemCount;
        public string itemName;
        public Sprite itemSprite;
    }
    public int Money = 0;
    public List<ItemData> itemData;


    public int GetItemCount(int itemID)
    {
        foreach (ItemData item in itemData)
        {
            if ((int)item.itemID == itemID)
            {
                Debug.Log($"GetItemCount : {item.itemName} = {item.itemCount}");
                return (int)item.itemCount;
            }
        }

        Debug.LogWarning($"GetItemCount ���� : ItemID {itemID}");
        return 0;
    }

    public void AddItem(int itemID, int count)
    {
        Debug.Log($"AddItem ȣ���");
        Debug.Log($"�߰��� ItemID : {itemID}");
        Debug.Log($"�߰��� ���� : {count}");

        foreach (ItemData item in itemData)
        {
            Debug.Log($"�˻��� : {item.itemName} ({item.itemID})");

            if ((int)item.itemID == itemID)
            {
                Debug.Log($"��Ī ���� : {item.itemName}");

                item.itemCount += count;

                Debug.Log($"���� �� ���� : {item.itemCount}");

                return;
            }
        }

        Debug.LogError($"ItemID {itemID} �� ���� �������� ã�� �� ����");
    }

    public bool ConsumeItem(int itemID, int count)
    {
        foreach (ItemData item in itemData)
        {
            if ((int)item.itemID == itemID)
            {
                if (item.itemCount < count)
                {
                    Debug.Log($"�Ҹ� ���� : {item.itemName}");
                    return false;
                }

                item.itemCount -= count;

                Debug.Log($"�Ҹ� ���� : {item.itemName}");
                Debug.Log($"���� ���� : {item.itemCount}");

                return true;
            }
        }

        Debug.LogError($"ConsumeItem ���� : ItemID {itemID}");
        return false;
    }

    // ��� �������� ������ 0���� �ʱ�ȭ�մϴ�.
    public void ClearItem()
    {
        if (itemData == null)
        {
            Debug.LogWarning("ClearItem: itemData�� null�Դϴ�.");
            return;
        }

        foreach (var item in itemData)
        {
            item.itemCount = 0;
        }

        Debug.Log("ClearItem: ��� ������ ������ 0���� �ʱ�ȭ�߽��ϴ�.");
    }
}